certmule
========

This is an x509 certificate wrapper in the form of an EFI binary.  It is
designed to be "safe" to sign, in terms of not needing to worry about what
happens if anyone runs the code, which can be very easily trusted and trivially
examined for modification in both source and binary form.
